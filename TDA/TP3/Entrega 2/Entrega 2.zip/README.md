
El programa es
./rectangulo_contenedor.py
Programado en python 3
Se ejecuta como:
./rectangulo_contenedor.py archivo_de_vertices metodo


Para generar vertices se puede utilizar un programa interactivo aparte
./seleccionar_puntos.py
En este es posible obtener la clausura convexa de puntos elegidos de forma
interactiva

Controles para el programa interactivo:

Click izquierdo: Crea un punto
Click izquierdo sobre un punto: Elimina un punto
Click derecho: Construye el polígono convexo utilizando el método de graham

Una vez obtenido el polígono convexo:
r: Construye el rectángulo contenedor utilizando el método de división y conquista
t: Construye el rectángulo contenedor utilizando el método naïve
