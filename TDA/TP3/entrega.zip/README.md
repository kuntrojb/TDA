
El programa es
./rectangulo_contenedor.py
Programado en python 3
Se ejecuta como:
./rectangulo_contenedor.py archivo_de_vertices metodo


Para generar vertices se puede utilizar un programa interactivo aparte
./seleccionar_puntos.py
En este es posible obtener la clausura convexa de puntos elegidos de forma
interactiva
