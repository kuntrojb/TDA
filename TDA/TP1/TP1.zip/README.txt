El programa utiliza python3

y debe ser ejecutado de la forma

./donantes.py [cantidad de pacientes] [cantidad de donantes] [pd]
