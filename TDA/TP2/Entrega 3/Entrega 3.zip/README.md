
Los programas son:
./comunicacion_satelital_comprimir.py
./comunicacion_satelital_descomprimir.py
Ambos programados en python 3
Se ejecutan como:
./comunicacion_satelital_comprimir.py archivo_de_frecuencias archivo_de_mensaje archivo_generado
./comunicacion_satelital_descomprimir.py archivo_de_frecuencias archivo_de_mensaje archivo_generado

